
//project is built off of practice solution 

function max_num(){ //function for choosing max number
    maxnum = parseInt(prompt("Enter your desired maximum number.")); //Pop-up user-input message 
   

    if (maxnum <= 0) { //validates user input 
        alert("You must enter a positive integer.")
    }
    else if (isNaN (maxnum)){ //will not accept user inputs that are not numbers 
        alert("You must enter a valid number.")
    }
    else{
        document.getElementById("note").innerHTML="You have chosen "+maxnum+" as your maximum number."
        document.getElementById("note2").innerHTML="Now try to guess the number. Good Luck!"
        number = Math.floor(Math.random() * maxnum) + 1 //Randomnly chooses number between 1-N
        console.log(number); //Displays number you chose in consoler 
        
  
    }
}

var guessesTotal = []; //array to contain user guesses 


function do_guess() { 

   
    
    
    let guess = Number(document.getElementById("guess").value);

    let message = document.getElementById("message");

    
    
    if(guess == number) {       
        guessesTotal.push(guess);
        console.log(guessesTotal);                                                                                                                  
        message.innerHTML = "You got it! It took you " + (guessesTotal.length) +" tries and your guesses were "+ guessesTotal.join(" , ")+"."; 
    }                                                      //length counts amount of tries and join concatenates different numbers inputted 
    else if (guessesTotal.filter((x) => x == guess).length){ //filter is used to check for previous duplicate inputs 
        message.innerHTML = "You have already entered this number.";
    }
    else if(guess == 0 || guess > maxnum){ //will not accept 0's or any number above the desired maximum number 
        message.innerHTML = "That number is not in range, try again!"
    }
    else if (guess > number) {
        message.innerHTML = "Incorrect, enter a lower number.";
        guessesTotal.push(guess);
        console.log(guessesTotal);
    }
    else if(guess < number) {
        message.innerHTML = "Incorrect, enter a higher number.";
        guessesTotal.push(guess);
        console.log(guessesTotal);
    }
    else if(isNaN(guess)) {
        message.innerHTML = "That is not a number!";
    }
   
    
}
    
    
   



    



        


